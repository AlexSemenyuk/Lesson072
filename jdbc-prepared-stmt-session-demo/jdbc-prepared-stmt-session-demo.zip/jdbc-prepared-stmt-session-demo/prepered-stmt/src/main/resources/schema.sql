drop database if exists blog;
create database blog default char set utf8;
use blog;
create table users
(
    id int primary key auto_increment,
    login varchar(100) not null unique ,
    password varchar(50) not null ,
    created timestamp,
    modified timestamp
);
grant all privileges on blog.* to blogApp identified by 'blogPass';