package org.itstep.dao;

import java.util.List;

// Data Access Object
public interface GenericDao<T, ID> {
    ID save(T data);
    T findById(ID id);
    List<T> findAll();
}
