package org.itstep.dao.impl;

import org.itstep.DbUtils;
import org.itstep.dao.UserDao;
import org.itstep.data.User;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class UserDaoImpl implements UserDao {

    private final DbUtils dbUtils;

    private final static String INSERT = "INSERT INTO users(login, password) VALUES ('%s', '%s')";

    public UserDaoImpl(String url, String username, String password) {
        dbUtils = DbUtils.getInstance();
        dbUtils.init(url, username, password);
    }

    @Override
    public Integer save(User data) {
        try {
            Optional<Connection> optionalConnection = dbUtils.getConnection();
            optionalConnection.ifPresent(connection -> {
                try {
                    var stmt = connection.createStatement();
                    stmt.executeQuery(INSERT.formatted(data.getLogin(), data.getPassword()));
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                } finally {
                    try {
                        connection.close();
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return null;
    }

    @Override
    public User findById(Integer integer) {
        return null;
    }

    @Override
    public List<User> findAll() {
        return null;
    }
}
