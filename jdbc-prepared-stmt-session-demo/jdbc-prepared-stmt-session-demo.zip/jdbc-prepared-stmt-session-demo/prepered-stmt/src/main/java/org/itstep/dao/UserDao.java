package org.itstep.dao;

import org.itstep.data.User;

public interface UserDao extends GenericDao<User, Integer> {
}
